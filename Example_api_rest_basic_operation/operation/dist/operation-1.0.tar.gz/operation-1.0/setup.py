from setuptools import setup

setup(name='operation',
      version='1.0',
      description='Basic operations over two lists',
      author='Luis Ernesto Farah',
      author_email='luisernesto.farahfernandez@altran.com',
      url='',
      packages=[],
      )
